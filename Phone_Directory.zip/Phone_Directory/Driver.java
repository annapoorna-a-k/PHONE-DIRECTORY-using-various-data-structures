package Phone_Directory;

import java.io.IOException;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) throws IOException {
		Contact_Dictionary contact = new Contact_Dictionary();
		MainMenu.main(args);
	}
}